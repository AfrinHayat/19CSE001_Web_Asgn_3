﻿<?php include 'inc/admin_header.php';?>
<?php include 'inc/admin_sidebar.php';?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Post List</h2>
                <div class="block">
					<div id="example_length" class="dataTables_length">
						<label>
							Show
							<select size="1" name="example_length">
								<option value="10" selected="selected">10</option>
								<option value="10" selected="selected">25</option>
							</select> entries
							</label>
					</div>

					<div class="dataTables_filter" id="example_filter">
						<label>
							Search
							<input type="text">
						</label>
					</div>
                    <table class="data display datatable" id='example'>
					<thead>
						<tr>
							<th width="5%">No.</th>
							<th width="15%">Post title</th>
							<th width="15%">Description</th>
							<th width="10%">Category</th>
							<th width="10%">Image</th>
							<th width="10%">Author</th>
							<th width="10%">Tags</th>
							<th width="10%">Date</th>
							<th width="10%">Action</th>
						</tr>
					</thead>
					<tbody>

					<?php
					$query = "select tbl_post.*, tbl_category.name from tbl_post
								inner join tbl_category
								on tbl_post.cat = tbl_category.id
								order by tbl_post.title desc";
								$post = $db->select($query);
									if($post){
										$i=0;
										while($result = $post->fetch_assoc()){
											$i++;
					?>
					
					<tr class="odd gradeX">
							<td><?php echo $i;?></td>
							<td><a href="editpost.php?editpostid=<?php echo $result['id']; ?>"><?php echo $result['title']; ?></td>
							<td><?php echo $fm->textShorten($result['body'], 50); ?></td>
							<td><?php echo $result['name']; ?></td>
							<td><img src="<?php echo $result['image']; ?>" height="40px" width="60px"/></td>
							<td><?php echo $result['author']; ?></td>
							<td><?php echo $result['tags']; ?></td>
							<td><?php echo $fm->formateDate($result['date']); ?></td>
							<td><a href="editpost.php?editpostid=<?php echo $result['id']; ?>">Edit</a> || <td><a onclick="return confirm('Are you sure to Delete!');" href="deletepost.php?delpostid=<?php echo $result['id']; ?>">Delete</a> 
						</tr>
					<?php } } ?>
					</tbody>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	
<script type="text/javascript">
      $(document).ready(function () {
        setupLeftMenu();
        $('.datatable').dataTable();
		setSidebarHeight();
        });
    </script>

<?php include 'inc/admin_footer.php';?>

