<?php
define("DB_HOST", "localhost");
define("DB_USER", "id19308035_admin");
define("DB_PASS", "PDEQkgi6*9pYjIu[");
define("DB_NAME", "id19308035_assignment_web_eng");
define("TITLE", "assignment_web_eng");
define("KEYWORDS", "PHP Tutorials , Java Tutorials , Oracle Database , C# Tutorials");

